# Smart Motion-Aware Servo System (ESP32 + OLED + Wi-Fi + ThingSpeak)

## Overview
This IoT project detects motion using a PIR sensor, scans direction with an ultrasonic sensor by sweeping a servo, locks onto the closest object, activates a buzzer, displays status on an OLED screen, and uploads motion/angle/distance data to ThingSpeak via Wi-Fi.

## Files
- `main.ino` : Main Arduino sketch for ESP32 (use ESP32 Dev Module board)
- `README.md`: This file
- `diagram.png`: Circuit diagram placeholder image

## Components
- ESP32 DevKit (NodeMCU-32S or similar)
- PIR Motion Sensor (HC-SR501)
- Ultrasonic Sensor (HC-SR04)
- SG90 Servo Motor
- OLED 0.96" (SSD1306, I2C)
- Buzzer (active)
- Breadboard and jumper wires
- 5V power supply for servo (recommended separate if high torque)

## Wiring (ESP32-32X recommended pins)
| Component | ESP32 Pin |
|-----------|-----------|
| PIR OUT   | GPIO13    |
| Ultrasonic TRIG | GPIO12 |
| Ultrasonic ECHO | GPIO14 |
| Servo Signal | GPIO27 (in code defined SERVO_PIN 27) |
| Buzzer | GPIO26 |
| OLED SDA | GPIO21 |
| OLED SCL | GPIO22 |
| VCC | 5V / 3.3V per component requirements |
| GND | GND (common) |

## ThingSpeak Fields
- Field1: motion (1 = detected)
- Field2: servo angle (degrees)
- Field3: distance (cm)

## Usage
1. Replace `YOUR_WIFI_SSID`, `YOUR_WIFI_PASSWORD`, and `YOUR_THINGSPEAK_WRITE_APIKEY` in `main.ino`.
2. Install required libraries in Arduino IDE: `Adafruit_SSD1306`, `Adafruit_GFX`, `ESP32Servo`.
3. Select board `ESP32 Dev Module` and upload `main.ino`.
4. Open ThingSpeak channel to view incoming data (ensure channel has fields set).

## Notes
- Use an external 5V supply for the servo if it draws significant current; always connect grounds together.
- ThingSpeak free tier limits updates to 1 request per 15 seconds; code uses a 3s post delay only after detection — adjust if needed.
